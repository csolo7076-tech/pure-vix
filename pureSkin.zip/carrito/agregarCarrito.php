<?php
$servidor = "localhost";
$usuario = "root";
$contraseña = "";
$baseDatos = "PureSkin";

$conexion= new mysqli($servidor, $usuario, $contraseña, $baseDatos);
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}



$codigo=$_POST['codigo'];
$idpedido=$_POST['idpedido'];
$cantidad=$_POST['cantidad'];
$precio=$_POST['precio'];
$total=$precio*$cantidad;

$sql = "INSERT INTO carrito (Productos_CodigoProductos, Pedidos_idPedidos, Cantidad, CostoTotal) 
VALUES ('$codigo', '$idpedido', '$cantidad', '$total')
ON DUPLICATE KEY UPDATE
    Cantidad = Cantidad + VAlUES(Cantidad)
    CostoTotal = Costototal + VALUES(CostoTotal)";

if ($conexion->query($sql)) {
    header("Location:../carrito/miCarrito.php?idPedido=" . $idpedido);
} else {
    echo "el producto ya se encuentra en el carrito";
    echo "<a href='../carrito/miCarrito.php?idPedido=$idpedido'> <button>Volver a Pedidos</button></a> ";
}
?>