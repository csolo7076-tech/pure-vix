<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        
        body{
            background-image: url(crema.avif);
            background-repeat: no-repeat;
            background-size: cover;
 height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:#DDEED8;
}
        

        .login{
            background: rgb(158, 196, 153);
            
            width:350px;
    
    padding:30px;
    border-radius:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.2);
        }
        
        .h2{
            display: flex;
      justify-content: center;
        }

        input{
    width:100%;
    padding:12px;
    margin-bottom:15px;
    border:1px solid #ddd;
    border-radius:10px;

        }
        .a{
            display: flex;
            justify-content: center;
        }

        button{
            width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#5f7d67;
    color:white;
    font-size:16px;
    cursor:pointer;
        }
    </style>
</head>
<body>
  <div class="login">

    <h2 class="h2">Iniciar Sesión</h2>

    <input type="email" placeholder="Correo electrónico">

    <input type="password" placeholder="Contraseña">

    <button>Entrar</button>

    <p class="a">
        <a href="registro.php">Crear cuenta</a>
    </p>

</div>
</body>
</html>