<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
<?php 
session_start();

if($_SESSION['ciusuario']==null){
    header("location:login.php");
}else{
    if($_SESSION['rol']=="Vendedor"){

}else{
    header("location:login.php");
}
}
 ?>
        body{
display: grid;
grid-template-columns: 100%;
grid-template-rows: auto auto auto auto auto auto ;
grid-template-areas:
"menu" 
"uno"
"dos"
"tres"
"cuatro"
"pie";



        }

        #menu{
            grid-area:menu;
        }
        #pie{
            grid-area:pie;
        }
.bienvenido{

    grid-area: uno;
    background:#8BA989;
    color:white;
    padding:20px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    
}

.bienvenido button{
    background:white;
    color:#5a7758;
    border:none;
    padding:10px 18px;
    border-radius:8px;
}
.perfil{
    
    border-radius: 5px;
    grid-area: dos;
}
.resumen{
    
    grid-area: tres;
}
.funciones{
   
    grid-area: cuatro;
}


.cajita{
    display: flex;
    flex-direction: row;
     background:white;
    border-radius:15px;
    padding:25px;
    text-align:center;
    box-shadow:0 5px 10px black;
}




.resumen{
    width:90%;
    margin:auto;
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:20px;
}

.perfil{
    width:90%;
    margin:30px auto;
    background:white;
    border-radius:15px;
    padding:25px;
    display:flex;
    align-items:center;
    gap:25px;
    box-shadow:0 5px 15px black;
}

.bienvenido{
    display: flex;
    justify-content: space-around;
}

.funciones{
     width:90%;
    margin:35px auto;
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:20px;
}


.funciones button{
    background:#8BA989;
    color:white;
    border:none;
    padding:18px;
    border-radius:12px;
    font-size:17px;
}



    </style>
</head>


<body>
    <section id="menu"><?php
      include('PAGINA/menu.php');
      ?></section>
    
    <section class="bienvenido">
        <h1>Bienvenid@ <?php echo $_SESSION['usuario'];?> </h1>
        
    </section>
    <section class="perfil">
        <h2>- <?php echo  $_SESSION['usuario'];?> de mascarillas faciales 
        <br>
    -ID: </h2>

    

    </section>

    <section class="resumen">
         <div class="cajita">
            <h3>Ventas hoy</h3>
         </div>

         <div class="cajita">
            <h3>Pedidos pendientes</h3>
         </div>

         <div class="cajita">
            <h3>Pedidos en Stock</h3>
         </div>
    </section>

    <div class="funciones">
         
        
            <a href="PAGINA/form_pedido.php"><button>Registrar Venta</button></a>
        
            <button>Consultar Stock</button>
       
            <a href="PAGINA/pedidos.php"><button>Gestionar Pedidos</button></a>
        
            <button>Historial de Ventas</button>
        
</div>
    

<section id="pie"><?php
include('PAGINA/piedepagina.php');
?></section>





</body>
</html>