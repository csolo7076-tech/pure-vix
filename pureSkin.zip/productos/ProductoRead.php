<?php
include("conexion.php");
if(!isset($_GET['ciusuario'])){
    die("No se recibio el CI del usuario");
}
$CodigoProductos=$_GET['CodigoProductos'];

$sql="SELECT * FROM productos WHERE CodigoProductos=$CodigoProductos";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    $fila=$resultado->fetch_assoc();
        echo $fila ['CodigoProductos']."<br>".$fila['Nombre']."<br>".$fila['Descripcion']."<br>".$fila['Precio']."<br>".$fila['Stock']."<br>";
    
}
else{
    echo "Producto no encontrado";
}




?>