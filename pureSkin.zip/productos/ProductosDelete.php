<?php

include("conexion.php");

$CodigoProductos=$_GET['CodigoProductos'];
$sql="DELETE  FROM productos WHERE CodigoProductos='$CodigoProductos'";
if($conexion->query($sql)===TRUE){
    header("location:ProductosRead.php?CodigoProductos=".$CodigoProductos);
    exit();
}
else{
    echo $conexion->error;
}

?>