<?php

include("conexion.php"); 

$Codigo=$_POST['CodigoProductos'];
$Nombre=$_POST['Nombre'];  
$Descripcion=$_POST['Descripcion'];
$Precio=$_POST['Precio'];
$Stock=$_POST['Stock'];

$sql ="UPDATE productos SET Nombre='$Nombre',Descripcion='$Descripcion', Precio='$Precio',Stock='$Stock' WHERE CodigoProductos='$Codigo'";
if ($conexion->query($sql)===TRUE){
 header ("location:ProductosRead.php?CodigoProductos=".$Codigo);
 exit();
}
else{
    echo $conexion->error;
}
?>