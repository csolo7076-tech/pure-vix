<?php

include("conexion.php");

$CodigoProductos=$_GET['CodigoProductos'];

$sql="SELECT * FROM productos WHERE CodigoProductos=$CodigoProductos";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    while($fila=$resultado->fetch_assoc()){
        $CodigoProductos=$fila['CodigoProductos'];
        $Nombre=$fila['Nombre'];
        $Descripcion=$fila['Descripcion'];
        $Precio=$fila['Precio'];
        $Stock=$fila['Stock'];
    }
} else {
        die("Producto no encontrado");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="ProductosUpdate.php" method="POST">
<label for="">Nombre</label>
<input type="text" name="Nombre" value="<?=$Nombre?>"> 
<br>
<label for="">Descripcion</label>
<input type="text" name="Descripcion" value="<?=$Descripcion?>"> 
<br>
<label for="">Precio</label>
<input type="number" name="Precio" value="<?=$Precio?>">
 <br>
<label for="">Stock</label>
<input type="text" name="Stock" value="<?=$Stock?>">
 <br>
<input type="hidden"   name="CodigoProductos" value="<?=$CodigoProductos?>">
<br>
<input type="submit" value="editar">

    </form>
</body>
</html>