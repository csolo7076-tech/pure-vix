<?php

include("conexion.php");

$Codigo=$_POST['CodigoProductos'];
$Nombre=$_POST['Nombre'];  
$Descripcion=$_POST['Descripcion'];
$Precio=$_POST['Precio'];
$Stock=$_POST['Stock'];

$sql ="INSERT INTO productos (`CodigoProductos`,`Nombre`, `Descripcion`, `Precio`, `Stock`) 
VALUES ('$Codigo','$Nombre','$Descripcion','$Precio','$Stock')";
if ($conexion->query($sql)===TRUE){
    header ("location:ProductosRead.php?CodigoProductos=".$Codigo);
    exit();
}
else{
    echo $conexion->error;
}
?>