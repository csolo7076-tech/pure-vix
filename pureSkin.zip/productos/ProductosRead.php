<?php
include("conexion.php");

session_start();
if (!isset($_SESSION['ciusuario'])) {
    header("Location: login.php");
    exit();
}
$CodigoProductos=$_GET['CodigoProductos'];
$sql="SELECT * FROM productos where CodigoProductos='$CodigoProductos'";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    while($fila=$resultado->fetch_assoc()){
        
echo $fila ['CodigoProductos']."<br>".$fila['Nombre']."<br>".$fila['Descripcion']."<br>".$fila['Precio']."<br>".$fila['Stock']."<br>";
$CodigoProductos=$fila['CodigoProductos'];

echo "<a href='ProductoRead.php?CodigoProductos=$CodigoProductos'><button> Mostrar </button></a><br>"; 
echo "<a href='ProductosUpdateform.php?CodigoProductos=$CodigoProductos'><button> Editar </button></a><br>"; 
echo "<a href='ProductosDelete.php?CodigoProductos=$CodigoProductos'><button> Eliminar </button></a><br>";
    }
}
?>