<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Documento</title>
</head>
<body>
    <form action="ProductosCreate.php" method="POST">
<label for="">Codigo</label>
<input type="number" name="CodigoProductos"> <br>
<label for="">Nombre</label>
<input type="text" name="Nombre"> <br>
<label for="">Descripcion</label>
<input type="text" name="Descripcion"> <br>    
<label for="">Precio</label>
<input type="number" name="Precio"> <br>
<label for="">Stock</label>
<input type="text" name="Stock"> <br>
<input type="submit" value="registrar">

    </form>
</body>
</html>