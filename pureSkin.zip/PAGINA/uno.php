<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    session_start(); // Inicia la sesión

$conexion = mysqli_connect("localhost","root","","pureskin");

$usuario = $_POST['Nombre'];
$clave = $_POST['CI'];

$sql = "SELECT * FROM usuario
        WHERE Nombre='$usuario'
        AND ciusuario='$clave'";

$resultado = mysqli_query($conexion,$sql);

if(mysqli_num_rows($resultado) > 0){

    $fila = mysqli_fetch_assoc($resultado);

    // Guardar datos en la sesión
    $_SESSION['ciusuario'] = $fila['ciusuario'];
    $_SESSION['usuario'] = $fila['Nombre'];
    $_SESSION['dire']=$fila['Direccion'];
    $_SESSION['rol']=$fila['Rol'];

}
if($_SESSION['rol']=="Vendedor"){



    header("Location:../nuevovendedor.php?ciusuario=".$clave);

}else{
    if($_SESSION['rol']=="Administrador"){



    header("Location:../administradornuevo.php?ciusuario=".$clave);

}else{
    echo "Usuario o contraseña incorrectos";
}
}


?>
</body>
</html>