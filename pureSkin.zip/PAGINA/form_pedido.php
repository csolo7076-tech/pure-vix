<?php
   session_start();
   if($_SESSION['ciusuario']==null){
    header("location:login.php");
}else{
    if($_SESSION['rol']=="Vendedor"){
$vendedor = $_SESSION['usuario'];
}else{
    header("location:login.php");
}
}
   
   ?>
<!DOCTYPE html>
<html>
<head>


<style>
   body{
    font-family: Arial, Helvetica, sans-serif;
    background: #eef5ee;
    margin: 0;
}

h2{
    text-align: center;
    color: #5f7d67;
    margin-top: 50px;
    margin-bottom: 20px;
}

form{
    width: 400px;
    margin: auto;
    background: white;
    padding: 30px;
    border-radius: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,.1);
}

input[type="text"],
input[type="date"]{
    width: 100%;
    padding: 12px;
    margin-top: 8px;
    margin-bottom: 18px;
    border: 1px solid #cfd8cf;
    border-radius: 10px;
    box-sizing: border-box;
    background: #f8faf8;
    font-size: 15px;
}

input[readonly]{
    background: #edf3ed;
}

input[type="submit"]{
    width: 100%;
    padding: 12px;
    background: #5f7d67;
    color: white;
    border: none;
    border-radius: 10px;
    font-size: 16px;
    cursor: pointer;
    transition: .3s;
}

input[type="submit"]:hover{
    background: #4f6a57;
}
</style>





    <title>Nuevo Pedido</title>
</head>
<body>
   <h2>Generar Pedido</h2>
   <form action="nuevo_pedido.php" method="post">
      Nombre:
      <input type="text"  name="nombre" required><br><br>

      Fecha:
      <input type="date" id="fecha" name="fecha" value="<?php echo date('Y-m-d'); ?>" readonly><br><br>

      <input type="hidden" name="estado" value="Pendiente">
       


      Nombre Vendedor:

      <input type="text" name="nombreVendedor" value="<?php echo $vendedor; ?>" readonly><br><br>

      <input type="submit" value="Nuevo Pedido">
   </form>
</body>
</html>