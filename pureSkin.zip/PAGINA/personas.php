<?php
include ("conexion.php");
session_start();
if (!isset($_SESSION['ciusuario'])) {
    header("Location: login.php");
    exit();
}
$sql="SELECT * FROM usuario";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    while($fila=$resultado->fetch_assoc()){
        
echo $fila ['ciusuario']."<br>".$fila['Nombre']."<br>".$fila['Direccion']."<br>".$fila['Celular']."<br>".$fila['Rol']."<br>".$fila['Estado']."<br>".$fila['Correo']."<br>";
$ciusuario=$fila['ciusuario'];

echo "<a href='persona.php?ciusuario=$ciusuario'><button> Mostrar </button></a>";<br>
echo "<a href='formEditar.php?ciusuario=$ciusuario'><button> Editar </button></a>";<br>
echo "<a href='eliminar.php?ciusuario=$ciusuario'><button> Eliminar </button></a>";<br>


    }


}


?>
