<?php
include("../PAGINA/conexion.php");

$sql="SELECT * FROM usuario";
$resultado=$conexion->query($sql);



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
table{
    width: 100%;
    margin-top: 20px;
    border-collapse: collapse;
    background: white;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 4px 10px rgba(0,0,0,0.08);
}

th{
    background: #5f7d67;
    color: white;
    padding: 15px;
    font-size: 16px;
    text-transform: uppercase;
}

td{
    padding: 14px;
    text-align: center;
    color: #444;
    border-bottom: 1px solid #e6e6e6;
}

tr:nth-child(even){
    background-color: #f6faf6;
}

tr:hover{
    background-color: #e8f2e8;
    transition: 0.3s;
}

button{
    border: none;
    padding: 9px 16px;
    border-radius: 8px;
    color: white;
    font-weight: bold;
    cursor: pointer;
    transition: 0.3s;
}

button:hover{
    transform: scale(1.05);
}

.registrar{
    background: #5f7d67;
}

.registrar:hover{
    background: #4f6a57;
}

.editar{
    background: #73a37b;
}

.editar:hover{
    background: #618d68;
}

.eliminar{
    background: #d45d5d;
}

.eliminar:hover{
    background: #b94a4a;
}

.rol{
    background: #d9a441;
}

.rol:hover{
    background: #bd8c2f;
}

.cerrarsesion{
    background: #5f7d67;
}

.cerrarsesion:hover{
    background: #4f6a57;
}




 <?php 
session_start();

if($_SESSION['ciusuario']==null){
    header("location:../logueo/login.php");
}else{
    if($_SESSION['rol']=="Administrador"){

}else{
    header("location:../logueo/login.php");
}
}
 ?>
body{
    display: grid;
    grid-template-columns: 100%;
    grid-template-rows:  auto auto auto auto auto auto auto auto;
    grid-template-areas: 
    "uno"
    "dos"
    "tres"
    "cuatro"
    "cinco"
    "seis";
}

.bienvenida{
    grid-area: uno;
      display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.contaduria{
    grid-area: dos;
     display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:20px;
    margin-bottom:35px;
}

.cajita{
      background:white;
    padding:25px;
    border-radius:15px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
    text-align:center;
}

.cajita h2{
    color:#5f7d67;
    font-size:35px;
}
.gestionusuario{
    grid-area: tres;
    background:white;
    margin-bottom:30px;
    border-radius:15px;
    padding:25px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
}





.gestionusuario h2{
color:#5f7d67;
    margin-bottom:8px;
}

table{
      width:100%;
    border-collapse:collapse;
}

th{
    background:#5f7d67;
    color:white;
    padding:14px;
}

td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #ddd;
}

button{
    border:none;
    padding:9px 15px;
    border-radius:8px;
    color:white;
    cursor:pointer;
    margin:2px;
    transition:.3s;
}
.gestionproductos{
    grid-area: cuatro;
}

.ventasypedido{
    grid-area: cinco;
}

.reportes{
    grid-area: seis;
}


.registrar{
     background:#5f7d67;
    margin-top:20px;
}

.rol{
    background:#d9a441;
}

.editar{
    background:#73a37b;
}
.eliminar{
     background:#d45d5d;
}

.cerrarsesion{
    background: #5f7d67;
}
    </style>
</head>
<body>
   

    <section class="bienvenida">
        <h2>Bienvenid@ <?php echo $_SESSION['usuario'];?> </h2>
       <a href="../logueo/logoul.php"> <button class="cerrarsesion">Cerrar Sesion</button></a>
    </section>

<section class="contaduria">
     <div class="cajita">
<h2>120</h2>
<p>Pedidos</p>
</div>

<div class="cajita">
<h2>120</h2>
<p>Usuarios</p>
</div>

<div class="cajita">
<h2>120</h2>
<p>Productos</p>
</div>

<div class="cajita">
<h2>120</h2>
<p>Ganancias</p>
</div>
</section>
 

    
    <div class="gestionusuario">

        <h2> Gestión de Usuarios</h2>

<p>Crear, editar, eliminar usuarios y asignar roles.</p>


<table>
<tr>
    <th>CI</th>
    <th>Nombre</th>
    <th>Dirección</th>
    <th>Celular</th>
    <th>Rol</th>
    <th>Estado</th>
    <th>Acciones</th>
</tr>
<?php 
if($resultado->num_rows>0){ 
    while($fila=$resultado->fetch_assoc()){
        
echo "<tr>";
echo "<td>".$fila['ciusuario']."</td>";
echo "<td>".$fila['Nombre']."</td>";
echo "<td>".$fila['Direccion']."</td>";
echo "<td>".$fila['Celular']."</td>";
echo "<td>".$fila['Rol']."</td>";
echo "<td>".$fila['Estado']."</td>";
$ciusuario=$fila['ciusuario'];

echo "<td>
<a href='../usuario/UsuarioRead.php?ciusuario=$ciusuario'>
<button class='rol'>Mostrar</button>
</a>

<a href='../usuario/UsuarioUpdateform.php?ciusuario=$ciusuario'>
<button class='editar'>Editar</button>
</a>

<a href='../usuario/UsuarioDelete.php?ciusuario=$ciusuario'>
<button class='eliminar'>Eliminar</button>
</a>
</td>";

echo "</tr>";


    }


}
?>

</table>

<a href=../usuario/UsuarioformCreate.php"><button class="registrar">+ Registrar Usuario</button></a>

</div>
    </div>



    
    <div class="gestionproductos">
        <h2> Gestión de Productos</h2>

<p>Registrar, editar y eliminar productos.</p>

<table>

<tr>
<th>Producto</th>
<th>Stock</th>
<th>Precio</th>
<th>Acciones</th>
</tr>

<tr>
<td>Mascarilla Aloe Vera</td>
<td>35</td>
<td>Bs 20</td>
<td>
<button class="editar">Editar</button>
<button class="eliminar">Eliminar</button>
</td>
</tr>

<tr>
<td>Mascarilla de Coco</td>
<td>18</td>
<td>Bs 25</td>
<td>
<button class="editar">Editar</button>
<button class="eliminar">Eliminar</button>
</td>
</tr>

</table>

<button class="registrar">+ Registrar Producto</button>

</div>
    </div>


    <div class="ventasypedido">
        <h2> Ventas y Pedidos</h2>

<p>Supervisión de las ventas realizadas y estado de los pedidos.</p>

<table>

<tr>
<th>Cliente</th>
<th>Producto</th>
<th>Estado</th>
<th>Total</th>
</tr>

<tr>
<td>Ana Rojas</td>
<td>Mascarilla Aloe Vera</td>
<td>Entregado</td>
<td>Bs 20</td>
</tr>

<tr>
<td>Lucía Gómez</td>
<td>Mascarilla de Coco</td>
<td>Pendiente</td>
<td>Bs 25</td>
</tr>

</table>

    </div>


<section class="reportes">
    <h2> Reportes</h2>

<p>Consulta información importante del sistema.</p>

<table>

<tr>
<th>Reporte</th>
<th>Descripción</th>
</tr>

<tr>
<td>Ventas Mensuales</td>
<td>Resumen de ventas del mes.</td>
</tr>

<tr>
<td>Productos Más Vendidos</td>
<td>Productos con mayor demanda.</td>
</tr>

<tr>
<td>Usuarios Registrados</td>
<td>Total de administradores y vendedores.</td>
</tr>

</table>
</section>










</body>
</html>