<?php
include("conexion.php");
if(!isset($_GET['ciusuario'])){
    die("No se recibio el CI del usuario");
}
$ciusuario=$_GET['ciusuario'];
$sql="SELECT * FROM usuario WHERE ciusuario='$ciusuario'";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    $fila=$resultado->fetch_assoc();
        echo $fila ['ciusuario']."<br>".$fila['Nombre']."<br>".$fila['Direccion']."<br>".$fila['Celular']."<br>".$fila['Rol']."<br>".$fila['Estado']."<br>".$fila['Correo']."<br>";
    
}
else{
    die("Usuario no encontrado");
}




?>
