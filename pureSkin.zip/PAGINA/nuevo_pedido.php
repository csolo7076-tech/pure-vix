<?php
$servidor = "localhost";
$usuario = "root";  
$contrasena = "";
$nombreBase = "PureSkin";

$conexion= new mysqli ($servidor, $usuario, $contrasena, $nombreBase);
 if ($conexion->connect_error) {
    die("Error al conectar a la base de datos: " . $conexion->connect_error);
}

$nombre = $_POST['nombre'];
$fecha = $_POST['fecha'];
$estado = $_POST['estado'];
$nombreVendedor = $_POST['nombreVendedor'];

$sql = "INSERT INTO pedidos (nombre, fecha, estado, nombreVendedor)
 VALUES ('$nombre', '$fecha', '$estado', '$nombreVendedor')";

 if($conexion->query($sql)){
 header("Location:../miCarrito.php?idPedido=".$conexion->insert_id);
} else {
    echo "Error al crear el pedido: ".$conexion->error;
}   
$conexion->close();
?>