<?php

$direccion="localhost";
$usuario="root"; 
$contraseña="";  
$nombreBase= "pureskin";

$conexion= new mysqli ($direccion, $usuario, $contraseña, $nombreBase);
if($conexion->connect_error){
    echo "hubo un error al conectar la base de datos";
}
echo ("si esta corriendo la base de datos");
session_start();
if (!isset($_SESSION['ciusuario'])) {
    header("Location: login.php");
}
$ciusuario=$_SESSION['ciusuario'];
$sql="SELECT * FROM usuario WHERE ciusuario='$ciusuario'";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    while($fila=$resultado->fetch_assoc()){
        echo $fila ['ciusuario']."<br>".$fila['Nombre']."<br>".$fila['Direccion']."<br>".$fila['Celular']."<br>".$fila['Rol']."<br>".$fila['Estado']."<br>".$fila['Correo']."<br>";
    }
}
echo "<a href='logoul.php'><button>Cerrar sesión</button></a>";


?>