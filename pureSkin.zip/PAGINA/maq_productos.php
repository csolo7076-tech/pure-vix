<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{

            display: grid;
            grid-template-rows: 400px auto auto auto;
            grid-template-columns: 100%;
            grid-template-areas: 
            "uno"
            "dos"
            "tres"
            "cuatro";
        }


        #uno{
          
            grid-area: uno;
padding: 20px;   
text-align: center; 
margin-bottom: 5%;
       
        }

        #dos{
            background-color: #F8F7F4;
            grid-area: dos;
        }

        #tres{
            background-color: #7ba975;
            grid-area: tres;
            display: flex;
            flex-direction: column;
            padding: 30px;
            margin-top:5%;
            border-radius:15px;
            width: 700px;
            margin: 5% auto;
            

        }

        h1{
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            font-size: 35px;
           color: white;
        }
h3{
    font-size:45px;
    text-align:center;
   
}
        .cajageneral{
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 5%;
            margin-top:15%;
        }
        
        .productos{
            background: white;
            width: 220px;
            box-shadow: 0 2px 8px black;
            border-radius: 15px;
            padding: 50px;

        }

        .a{
            background: #E7E3DA;
            display: flex;
            
            justify-content: center;
            border-radius: 20px;
            width: 200px;
            height: 45px;
            font-size:16px;
            color: #2F3A34;
            align-items: center;
            background-position: center;
         height: 60px;
            margin:20px auto;
            margin-bottom: 20px;
            
            
 



        }

        .cuatro{
            grid-area:cuatro;
        }
       
        .productos img{
            width:100%;
            border-radius:8px;
        }
    </style>
</head>
<body>
    <section id="uno">
        
    
      <?php
      include('../include/menu.php');
      ?>
    </section>

    <section id="dos">

        <div class="cajageneral">
        
        <div class="productos">
            <img src="Arroz.webp" alt="">
            <h2>Mascarilla de arroz</h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>

<div class="productos">
    <img src="avena.jpg" alt="">
            <h2>Mascarilla de avena</h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>

        <div class="productos">
            <img src="miel.jpg" alt="">
            <h2>Mascarilla de miel</h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>

        <div class="productos">
            <img src="cebolla.jpg" alt="">
            <h2>Mascarilla de cebolla</h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>

        <div class="productos">
            <img src="aloevera.jpg" alt="">
            <h2>Mascarilla de Aloe Vera </h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>

        <div class="productos">
            <img src="platano.avif" alt="">
            <h2>Mascarilla de Platano</h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>

        <div class="productos">
            <img src="pepino.jpg" alt="">
            <h2>Mascarilla de Pepino</h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>


        <div class="productos">
            <img src="papayita.jpg" alt="">
            <h2>Mascarilla de Papaya</h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>

        <div class="productos">
            <img src="manzanilla.jpg" alt="">
            <h2>Mascarilla Manzanilla</h2>
            <p>sirve para</p>
            <p>10bs</p>
            <p>agregar al carrito</p>
        </div>

        </div>
    </section>


    <section id="tres">
<h3>Descumbre más</h3>

<a  class="a" href="maq_catalogo.php">Ver Catálogo Completo </a>

    </section>

    <section class="cuatro">
<?php
include('../include/piedepagina.php');

        ?>
    </section>
</body>
</html>