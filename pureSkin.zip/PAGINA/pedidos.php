<?php

$direccion="localhost";
$usuario="root"; 
$contraseña="";  
$nombreBase= "pureskin";
$conexion= new mysqli ($direccion, $usuario, $contraseña, $nombreBase);
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$sql="SELECT * FROM Pedidos";
$resultado = $conexion->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Gestión de Pedidos</title>
    <style>
        body{
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        table{
            border-collapse: collapse;
            width: 100%;
        }

        th, td{
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th{
            background-color: #f2f2f2;
        }

        .aceptar{
            background-color: green;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
        }

        .rechazar{
            background-color: red;
            color: white;
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<h2>Lista de Pedidos</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Fecha</th>
        <th>Estado</th>
        <th>Vendedor</th>
        <th>Acciones</th>
    </tr>

    <?php while($fila = $resultado->fetch_assoc()) { ?>
    <tr>
        <td><?php echo $fila['idPedidos']; ?></td>
        <td><?php echo $fila['Nombre']; ?></td>
        <td><?php echo $fila['Fecha']; ?></td>
        <td><?php echo $fila['Estado']; ?></td>
        <td><?php echo $fila['NombreVendedor']; ?></td>
        <td>
            <a class="aceptar"
               href="pedidos.php?id=<?php echo $fila['idPedidos']; ?>&estado=Aceptado">
               Aceptar
            </a>

            <a class="rechazar"
               href="pedidos.php?id=<?php echo $fila['idPedidos']; ?>&estado=Rechazado">
               Rechazar
            </a>
        </td>
    </tr>
    <?php } ?>

</table>

</body>
</html>

