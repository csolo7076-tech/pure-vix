<style>
body{
    background:#f4f7f4;
    font-family:Arial, sans-serif;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
}

form{
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0 5px 15px rgba(0,0,0,.1);
    width:400px;
}

label{
    display:block;
    margin-top:12px;
    margin-bottom:5px;
    color:#5f7d67;
    font-weight:bold;
}

input[type="text"],
input[type="number"]{
    width:100%;
    padding:10px;
    border:1px solid #ddd;
    border-radius:8px;
    box-sizing:border-box;
}

input[type="text"]:focus,
input[type="number"]:focus{
    outline:none;
    border-color:#5f7d67;
}

input[type="submit"]{
    width:100%;
    margin-top:20px;
    padding:12px;
    background:#5f7d67;
    color:white;
    border:none;
    border-radius:8px;
    font-weight:bold;
    cursor:pointer;
    transition:.3s;
}

input[type="submit"]:hover{
    background:#4f6a57;
}
</style>


<?php

include("../PAGINA/conexion.php");

if(!isset($_GET['ciusuario'])){
    die("No se recibio el CI del usuario");
}
$ciusuario=$_GET['ciusuario'];

$sql="SELECT * FROM usuario WHERE ciusuario='$ciusuario'";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    $fila=$resultado->fetch_assoc();
        $Nombre=$fila['Nombre'];
        $Direccion=$fila['Direccion'];
        $Celular=$fila['Celular'];
        $Rol=$fila['Rol'];
        $Estado=$fila['Estado'];
    }
    else{
        die("Usuario no encontrado");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="../usuario/UsuarioUpdate.php" method="POST">
<label for="">Nombre</label>
<input type="text" name="Nombre" value="<?=$Nombre?>"> 
<br>
<label for="">Direccion</label>
<input type="text" name="Direccion" value="<?=$Direccion?>"> 
<br>
<label for="">Celular</label>
<input type="number" name="Celular" value="<?=$Celular?>">
 <br>
<label for="">Rol</label>
<input type="text" name="Rol" value="<?=$Rol?>">
 <br>
<label for="">Estado</label>
<input type="text" name="Estado" value="<?=$Estado?>">
<br>
<input type="hidden"   name="ciusuario" value="<?=$ciusuario?>">
<br>
<input type="submit" value="editar">

    </form>
</body>
</html>