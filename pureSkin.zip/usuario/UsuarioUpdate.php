<?php

include("conexion.php"); 

$ciusuario=$_POST['ciusuario'];
$Nombre=$_POST['Nombre'];
$Direccion=$_POST['Direccion'];
$Celular=$_POST['Celular'];
$Rol=$_POST['Rol'];
$Estado=$_POST['Estado'];
$sql ="UPDATE usuario SET Nombre='$Nombre',Direccion='$Direccion', Celular='$Celular',Rol='$Rol',Estado='$Estado' WHERE ciusuario='$ciusuario'";
if ($conexion->query($sql)===TRUE){
 header ("location:administradornuevo.php?ciusuario=".$ciusuario);
 exit();
}
else{
    echo $conexion->error;
}
?>