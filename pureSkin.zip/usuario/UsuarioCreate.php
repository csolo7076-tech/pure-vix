<?php

include("../PAGINA/conexion.php");

$Nombre=$_POST['Nombre'];
$ciusuario=$_POST['ciusuario'];  
$Direccion=$_POST['Direccion'];
$Celular=$_POST['Celular'];
$Rol=$_POST['Rol'];
$Estado=$_POST['Estado'];

$sql ="INSERT INTO usuario(`Nombre`,`ciusuario`, `Direccion`, `Celular`, `Rol`, `Estado`) 
VALUES ('$Nombre','$ciusuario','$Direccion','$Celular','$Rol','$Estado')";
if ($conexion->query($sql)===TRUE){
    header("Location: ../PAGINA/administradornuevo.php");
    exit();
}
else{
    echo $conexion->error;
}
?>