<?php
include("conexion.php");

session_start();
if (!isset($_SESSION['ciusuario'])) {
    header("Location:../logueo/login.php");
    exit();
}
$sql="SELECT * FROM usuario";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    while($fila=$resultado->fetch_assoc()){
        
echo $fila ['ciusuario']."<br>".$fila['Nombre']."<br>".$fila['Direccion']."<br>".$fila['Celular']."<br>".$fila['Rol']."<br>".$fila['Estado']."<br>";
$ciusuario=$fila['ciusuario'];

echo "<a href='UsuarioRead.php?ciusuario=$ciusuario'><button> Mostrar </button></a><br>"; 
echo "<a href='UsuarioUpdateform.php?ciusuario=$ciusuario'><button> Editar </button></a><br>"; 
echo "<a href='UsuarioDelete.php?ciusuario=$ciusuario'><button> Eliminar </button></a><br>";


    }


}


?>
