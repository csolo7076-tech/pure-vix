<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <title>Documento</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f7fb;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            background: #ffffff;
            padding: 28px;
            border-radius: 14px;
            box-shadow: 0 10px 25px rgba(15, 42, 81, 0.15);
            width: 340px;
            border-top: 5px solid #1e3a8a;
        }

        label {
            display: block;
            margin-top: 12px;
            font-weight: 600;
            color: #1f2a44; 
            font-size: 14px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 9px;
            margin-top: 6px;
            border: 1px solid #c7d2fe;
            border-radius: 8px;
            outline: none;
            transition: 0.3s;
            background: #f9fbff;
        }

        input[type="text"]:focus,
        input[type="number"]:focus {
            border-color: #3b82f6; 
            box-shadow: 0 0 6px rgba(59,130,246,0.25);
            background: #ffffff;
        }

        input[type="submit"] {
            margin-top: 18px;
            width: 100%;
            padding: 11px;
            background: #1e3a8a; 
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            letter-spacing: 0.5px;
            transition: 0.3s;
        }

        input[type="submit"]:hover {
            background: #274cbd; 
            transform: translateY(-1px);
            box-shadow: 0 6px 15px rgba(39,76,189,0.25);
        }
    </style>

</head>

<body>
    <form action="../usuario/UsuarioCreate.php" method="POST" id="usuario-form">
<label for="">Nombre</label>
<input type="text" name="Nombre"> <br>
<label for="">Cedula</label>
<input type="text" name="ciusuario"> <br>

<label for="">Direccion</label>
<input type="text" name="Direccion"> <br>    
<label for="">Celular</label>
<input type="number" name="Celular"> <br>
<label for="">Rol</label>
<input type="text" name="Rol"> <br>
<label for="">Estado</label>
<input type="text" name="Estado"> <br>
<input type="submit" value="REGISTRAR">

    </form>
    <script>
       $(function () {
       $("#usuario-form").validate({
        rules: {
            Nombre: {
                required: true,
                minlength: 3
            },
            ciusuario: {
                required: true,
                digits: true,
                minlength: 6
            },
            Direccion: {
                required: true
            },
            Celular: {
                required: true,
                digits: true,
                minlength: 8
            },
            Rol: {
                required: true
            },
            Estado: {
                required: true
            }
        },

        messages: {
            Nombre: {
                required: "El nombre es obligatorio",
                minlength: "Mínimo 3 caracteres"
            },
            ciusuario: {
                required: "La cédula es obligatoria",
                digits: "Solo números",
                minlength: "Debe tener al menos 6 dígitos"
            },
            Direccion: {
                required: "La dirección es obligatoria"
            },
            Celular: {
                required: "El celular es obligatorio",
                digits: "Solo números",
                minlength: "Número inválido"
            },
            Rol: {
                required: "El rol es obligatorio"
            },
            Estado: {
                required: "El estado es obligatorio"
            }
        }

    });

});
</script>

</body>
</html>
    </script>

</body>
</html>