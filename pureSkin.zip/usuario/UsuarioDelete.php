<?php

include("../PAGINA/conexion.php");

$ciusuario=$_GET['ciusuario'];
$sql="DELETE  FROM usuario WHERE ciusuario='$ciusuario'";
if($conexion->query($sql)===TRUE){
    header("location:../PAGINA/administradornuevo.php?ciusuario=".$ciusuario);
    exit();
}
else{
    echo $conexion->error;
}

?>