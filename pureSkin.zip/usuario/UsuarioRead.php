
<style>
body{
    background: linear-gradient(135deg, #eef5ee, #f7faf7);
    font-family: Arial, sans-serif;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    margin:0;
}

.perfil{
    background:white;
    width:380px;
    border-radius:18px;
    box-shadow:0 10px 25px rgba(0,0,0,0.12);
    overflow:hidden;
    border:1px solid #e6e6e6;
}

.header{
    background:#5f7d67;
    color:white;
    text-align:center;
    padding:20px;
    font-size:18px;
    font-weight:bold;
}

.contenido{
    padding:25px;
    line-height:2;
    color:#333;
}

.label{
    font-weight:bold;
    color:#5f7d67;
}

.item{
    border-bottom:1px solid #eee;
    padding:8px 0;
}

.item:last-child{
    border:none;
}
</style>

<?php
include("../PAGINA/conexion.php");
if(!isset($_GET['ciusuario'])){
    die("No se recibio el CI del usuario");
}
$ciusuario=$_GET['ciusuario'];
$sql="SELECT * FROM usuario WHERE ciusuario='$ciusuario'";
$resultado=$conexion->query($sql);
if($resultado->num_rows>0){ 
    $fila=$resultado->fetch_assoc();
       echo "<div class='perfil'>";

echo "<div class='header'>Información del Usuario</div>";

echo "<div class='contenido'>";

echo "<div class='item'><span class='label'>CI:</span> ".$fila['ciusuario']."</div>";
echo "<div class='item'><span class='label'>Nombre:</span> ".$fila['Nombre']."</div>";
echo "<div class='item'><span class='label'>Dirección:</span> ".$fila['Direccion']."</div>";
echo "<div class='item'><span class='label'>Celular:</span> ".$fila['Celular']."</div>";
echo "<div class='item'><span class='label'>Rol:</span> ".$fila['Rol']."</div>";
echo "<div class='item'><span class='label'>Estado:</span> ".$fila['Estado']."</div>";

echo "</div>";
echo "</div>"; 
}
else{
    echo "Usuario no encontrado";
}




?>
