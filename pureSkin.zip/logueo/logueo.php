<?php
$servidor = "localhost";
$usuario = "root";  
$contraseña = "";
$baseDatos = "pureskin";
$conexion = new mysqli($servidor, $usuario, $contraseña, $baseDatos);
if ($conexion->connect_error) {
    echo "Error al conectar ";
}
session_start();
$ciusuario = $_SESSION['ciusuario'];
$sql = "SELECT * FROM usuario WHERE ciusuario ='$ciusuario'";
 $resultado = $conexion->query($sql);
if ($resultado->num_rows > 0) {
   while ($fila= $resultado -> fetch_assoc()){
    echo $fila['ciusuario']."  ".$fila['Nombre']."  ".$fila['Direccion']."  ".$fila['Celular']."  ".$fila['Rol']."  ".$fila['Estado']."  ".$fila['Correo'];
   }}else{ 
    header("location:login.php");
}
?>             

