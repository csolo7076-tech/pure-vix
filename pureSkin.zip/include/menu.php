<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        nav li{

    font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif ;
font-size: 20px;
margin: 0 20px;

}

h1{
   color:white;
    
    display: flex;
    justify-content: center;
    
   font-family: Georgia, 'Times New Roman', Times, serif;
   font-size: 100px;
   
}


.header{
    background-image:url(PAGINA/crema.avif);
    background-repeat: no-repeat;
    background-size: cover;
    grid-area: uno;
    display: flex;
    justify-content: center;
    align-items: center;
    
    
    
}

nav{
    background-color: #D8E4D0;
    display: flex;
    display: grid;
    padding:20px;
    justify-content: center;
  
    align-items: center;
    grid-area: dos;
    
 
 

}

nav ul{
    display: flex;
    list-style: none;
    flex-wrap:wrap;
    padding: 0;
    margin: 0;
}

.menu{
    background:#1e293b;
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 8%;
}
.botoniniciosesion{
    background: #8BA888;
    color: white;
    padding:10px 10px;
        border-radius:5px;
}
.boton-menu{
display:none ;
background:none;
border: none;
color:white;
font-size: 2rem;
cursor:pointer; 
}

@media(max-width:700px){
    nav{
        padding:10px;
    }
    header{
        background-size:800px 250px;
    }
    .boton-menu{
    display:block;
}
 .nav-links{
        display:none;
        flex-direction:column;
        position:absolute;
        top:320px;
        left:0;
        width:100%;
        background: #b0caa7;
        text-align:center;
        padding:20px 0;
    }

    .nav-links.active{
        display:flex;
    }

    .nav-links li{
        margin:10px 0;
    }
}

.redireccion{
    color:black;
}



    </style>
</head>
<body>
    <header class="header">
        <h1>Pure Skin</h1>
    </header>
<nav>

<button class="boton-menu" id="btnMenu">
    ☰
</button>

    <nav>
        <ul  class="nav-links" id="navLinks">
            <li>Inicio</li>
            <li> <a class="redireccion" href="maq_productos.php">Productos</a></li>
            <li> <a href="maq_objetivos.php">Objetivos</a></li>
            <li> <a href="../logueo/login.php" class="botoniniciosesion"> Iniciar Sesión</a></li>
            <li><a href="../logueo/" class="botoniniciosesion">cerrar Sesion </a></li>
            <li>Carrito</li>
        </ul>
    
    
</nav>
 <script>
 var btnMenu = document.getElementById("btnMenu");
var navLinks = document.getElementById("navLinks");

btnMenu.addEventListener("click", () => {
    navLinks.classList.toggle("active");
});
    </script>
</body>
</html>