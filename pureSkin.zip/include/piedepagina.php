<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        footer{
    background-color: #5D735A;
    grid-area: cuatro;
    margin-top: 50px;
    padding: 40px;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    gap: 20px;
    }

    footer h4{
    font-size: 22px;
     margin-bottom:20px;
    color: white;
    display: flex;
}

footer p {
     line-height:2;
}
    </style>
</head>
<body>
    <footer>
        <div>
            <h4>PURE SKIN</h4>
            <p>
            Cosmética natural elaborada con ingredientes
            saludables para cuidar tu piel cada día.
        </p>

    </div>

    <div>

        <h4>Contacto</h4>

        <p>
            Av. Uyuni - Cochabamba <br>
            Horario: 9:00 - 18:00 <br>
            Bolivia
        </p>

    </div>
        
    </footer>
</body>
</html>